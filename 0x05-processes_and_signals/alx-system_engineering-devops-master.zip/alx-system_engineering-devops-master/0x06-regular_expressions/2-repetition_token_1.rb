#!/usr/bin/env ruby
puts ARGV[0].scan(/h+[b|t]t?n/).join
