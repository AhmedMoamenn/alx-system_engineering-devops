#!/usr/bin/env ruby
puts ARGV[0].scan(/h[a-zA-Z0-9]n/).join
