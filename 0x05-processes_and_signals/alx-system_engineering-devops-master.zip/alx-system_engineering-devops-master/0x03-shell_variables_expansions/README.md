# This project is for learning:
- Shell initialization files
- Variables
- Expansions
- Shell Arithmetic
- Alias command

Mar 29 2022
