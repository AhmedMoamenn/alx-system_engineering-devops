# 0x17. Web stack debugging #3
This was the fourth project in a series of web stack debugging projects. In these projects, I was given broken/bugged webstacks in isolated containers, and asked to fix them to a working state. For each task, I wrote a script automating the commands necessary to fix the
web stack.
