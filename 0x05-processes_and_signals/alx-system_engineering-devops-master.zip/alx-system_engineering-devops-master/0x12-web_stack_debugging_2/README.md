# 0x12-web_stack_debugging_2

This project is one among the debugging series where I am given broken code to write a solution script to
